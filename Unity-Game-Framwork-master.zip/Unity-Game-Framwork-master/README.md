Unity Game Framework
=====

environment: Unity(5.0+)

- Author: Chun-Lung(Gyd) Tseng
- Email: kingterrygyd@gmail.com
- Twitter: @kingterrygyd
- Facebook: facebook.com/barbariangyd
- Donation: <a href='https://pledgie.com/campaigns/32250'><img alt='Click here to lend your support to: Unity-HierarchyHelper and make a donation at pledgie.com !' src='https://pledgie.com/campaigns/32250.png?skin_name=chrome' border='0' ></a>

Kaohsiung, Taiwan, ROC
