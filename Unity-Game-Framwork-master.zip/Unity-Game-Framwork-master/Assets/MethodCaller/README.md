- Method Caller
- Drag script to any gameobject -> add method(s) -> play -> press "Run"
- Enjoy

![](https://i.imgur.com/WvtSaQW.gif)