- Window/Built-in styles and icons
- A modified version of http://wiki.unity3d.com/index.php/Show_Built_In_Resources
- Enjoy

![](http://i.imgur.com/gkk90Af.png)