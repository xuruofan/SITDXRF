- Tools/Monitor for Animation Curve
- Drag monitor GameObject with Animation or Animator to Object Field
- Enjoy

![](http://i.imgur.com/39ALYQW.gif)
