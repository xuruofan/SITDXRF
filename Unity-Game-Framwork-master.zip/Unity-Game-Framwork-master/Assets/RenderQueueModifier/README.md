- Render Queue Modifier
- Require NGUI
- Attach to the NGUI UIWigget which you want to modifier
- Set RenderType on Inspector
- Enjoy

